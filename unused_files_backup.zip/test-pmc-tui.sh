#!/bin/bash
# Test script to launch PMC FakeTUI and simulate keypresses

echo "Launching PMC FakeTUI..."
echo "Keys: F10=menu, Esc=exit, Alt+X=quick exit"
echo ""

# Launch PMC
pwsh ./pmc.ps1
